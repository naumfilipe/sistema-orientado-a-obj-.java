package questao2;

public class Gerente extends Empregado {
	
	public Gerente(String nome, String idade, String sexo, double salario, String matricula, double valorVendas, int qntVendas) {
		super(nome, idade, sexo, salario, matricula);
		this.valorVendas = valorVendas;
		this.qntVendas = qntVendas;
	}
	
	public double valorVendas;
	public int qntVendas;
	
	public double getValorVendas() {
		return valorVendas;
	}
	public void setValorVendas(double valorVendas) {
		this.valorVendas = valorVendas;
	}
	public int getQntVendas() {
		return qntVendas;
	}
	public void setQntVendas(int qntVendas) {
		this.qntVendas = qntVendas;
	}
	
}