package questao2;

public class Empregado extends Pessoa {
	
	public Empregado(String nome, String idade, String sexo, double salario, String matricula) {
		super(nome, idade, sexo);
		this.salario = salario;
		this.matricula = matricula;
	}

	public double salario;
	public String matricula;
	
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public double valorInss() {
		return this.salario = this.salario * (11/100);
	}
}