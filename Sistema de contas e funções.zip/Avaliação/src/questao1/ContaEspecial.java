package questao1;

public class ContaEspecial extends ContaBancaria{
	private double limite;
	
	public double getLimite() {
		return limite;
	}



	public void setLimite(double limite) {
		this.limite = limite;
	}



	
	@Override
	public void sacar(double valor) {
		this.limite = 10000.00;
		if (valor > limite) {
			System.out.println("Valor acima do limite \n");
		} else {
			saldo -= valor;
			System.out.println("Foi sacado "+valor+" reais da conta de: "+cliente);
		}
	}
}
