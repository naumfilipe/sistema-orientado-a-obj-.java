package questao2;

public class Cliente extends Pessoa {
	
	public Cliente(String nome, String idade, String sexo, String valorDivida2, String anoNascim2) {
		super(nome, idade, sexo);
	}

	private double valorDivida;
	private int anoNascim;
	
	public double getValorDivida() {
		return valorDivida;
	}
	public void setValorDivida(double valorDivida) {
		this.valorDivida = valorDivida;
	}
	public int getAnoNascim() {
		return anoNascim;
	}
	public void setAnoNascim(int anoNascim) {
		this.anoNascim = anoNascim;
	}
}