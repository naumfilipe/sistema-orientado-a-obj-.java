package questao2;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Teste{

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner entrada = new Scanner(System.in);
		int opcao;
		List<Cliente> clientes = new ArrayList<Cliente>();

		do{
			System.out.print("Digite 1 para cadastrar um cliente, (2 para sair):");
			opcao = Integer.parseInt(entrada.nextLine());
			switch(opcao){
				case 1:
					System.out.print("Digite o nome da pessoa: ");
					String nome = entrada.nextLine();
					System.out.print("Digite a idade da pessoa: ");
					String idade = entrada.nextLine();
					System.out.print("Digite o sexo da pessoa: ");
					String sexo =  entrada.nextLine();
					System.out.print("Digite o valor da dívida: ");
					String valorDivida = entrada.nextLine();
					System.out.print("Digite o ano de nascimento do cliente:");
					String anoNascim = entrada.nextLine();

					clientes.add(new Cliente(nome,idade,sexo,valorDivida,anoNascim));

					break;
				case 2:
					System.out.print("Desconectando...");
					break;
				default: System.out.println("Opção inválida.");
			}
		}while(opcao!=2);
	}
}