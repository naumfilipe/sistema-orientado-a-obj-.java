package questao1;

public class ContaPoupanca extends ContaBancaria {
	
	private double diaRendimento;

	
	public double getDiaRendimento() {
		return diaRendimento;
	}


	public void setDiaRendimento(double diaRendimento) {
		this.diaRendimento = diaRendimento;
	}

	
	public void novoSaldo() {
		this.diaRendimento = 0.005;
		this.saldo += saldo * diaRendimento;
		System.out.println("Seu saldo acrescido da taxa da rendimento é de: "+getSaldo());
	}
}