package questao2;

public class Diretor extends Empregado {
	
	public Diretor(String nome, String idade, String sexo, double salario, String matricula, String nomeDiretoria) {
		super(nome, idade, sexo, salario, matricula);
		this.nomeDiretoria = nomeDiretoria;
	}

	public String nomeDiretoria;

	public String getNomeDiretoria() {
		return nomeDiretoria;
	}

	public void setNomeDiretoria(String nomeDiretoria) {
		this.nomeDiretoria = nomeDiretoria;
	}
}