package questao1;
public class Contas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ContaPoupanca contaP = new ContaPoupanca();
		contaP.setCliente("Robson");
		contaP.setNum_conta(5040);
		contaP.setSaldo(4000.00);

		System.out.println("Conta Bancária de "+contaP.cliente+"\nNúmero da conta: "
				+contaP.num_conta+"\nSaldo: "+contaP.saldo);

		contaP.sacar(400);
		contaP.novoSaldo();
		contaP.depositar(1000);
		contaP.novoSaldo();

		System.out.println("\nConta Poupança de "+contaP.cliente+"\nNúmero da conta: "
				+contaP.num_conta+"\nSaldo: "+contaP.saldo+"\nRendimento: "+contaP.getDiaRendimento());


		ContaEspecial contaE = new ContaEspecial();
		contaE.setCliente("Maria");
		contaE.setNum_conta(2020);
		contaE.setSaldo(10000.00);

		System.out.println("\n\n\nConta Especial de "+contaE.cliente+"\nNúmero da conta: "
				+contaE.num_conta+"\nSaldo: "+contaE.saldo+"\nLimite: "+contaE.getLimite());
		
		contaE.sacar(20000);
		contaE.mostrarSaldo();
		
		
		System.out.println("\nConta Especial de "+contaE.cliente+"\nNúmero da conta: "
				+contaE.num_conta+"\nSaldo: "+contaE.saldo+"\nLimite: "+contaE.getLimite());
	}

}