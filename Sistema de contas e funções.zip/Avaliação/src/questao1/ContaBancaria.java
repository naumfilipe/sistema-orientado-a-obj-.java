package questao1;

public class ContaBancaria {

	protected String cliente;
	protected int num_conta;
	protected double saldo;




	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public int getNum_conta() {
		return num_conta;
	}

	public void setNum_conta(int num_conta) {
		this.num_conta = num_conta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	

	public void sacar(double valor) {		 
		if (valor > this.saldo) {
			System.out.println("Saldo insuficiente! \n");
		} else {
			saldo -= valor;
			System.out.println("\nFoi sacado "+valor+" reais da conta de "+cliente+" Saldo atual de: "+saldo);
		}
	}

	public void depositar(double valor) {
		saldo += valor;
		System.out.println("Foi depositado "+valor+" reais na conta de: "+cliente);
	}

	public void mostrarSaldo() {
		System.out.println(cliente+" seu saldo é de: "+saldo+" reais");
	}
}
